// import sum from "./second.js";
const sum  = require("./second")

sum(3,8);

console.log("Hello Ji");